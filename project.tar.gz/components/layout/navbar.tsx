export function Navbar() {
  return (
    <nav className="border-b px-4 py-2">
      <div className="flex items-center justify-between">
        <span className="font-bold">Sitiy Han ERP</span>
      </div>
    </nav>
  )
}
