export default function ProcurementPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Закупки</h1>
    </div>
  )
}
