export default function RecipesPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Рецепты и калькуляция</h1>
    </div>
  )
}
