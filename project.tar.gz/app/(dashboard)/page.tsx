export default function DashboardPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Панель управления</h1>
      <p>Добро пожаловать в Sitiy Han ERP</p>
    </div>
  )
}
