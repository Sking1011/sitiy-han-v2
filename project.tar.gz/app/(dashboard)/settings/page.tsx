export default function SettingsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Настройки</h1>
    </div>
  )
}
