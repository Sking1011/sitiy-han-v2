export default function SalesPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Продажи</h1>
    </div>
  )
}
